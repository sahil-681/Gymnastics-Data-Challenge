library(dplyr)
library(stringr)
d1 <- read.csv("data/data_2017_2021.csv")
d2 <- read.csv("data/data_2022_2023.csv")







